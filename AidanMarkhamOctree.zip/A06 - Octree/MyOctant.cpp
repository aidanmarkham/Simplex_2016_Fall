#include "MyOctant.h"

using namespace Simplex;

void Simplex::MyOctant::Display(int depth)
{

	if (depth < m_depth) {

		m_pMeshMngr->AddWireCubeToRenderList(glm::translate(m_pAABB->Center()) * glm::scale(m_pAABB->Size()), C_YELLOW);

		for (int i = 0; i < m_childCount; i++) {
			m_pChildren[i]->Display(depth + 1);
		}
	}

}

void Simplex::MyOctant::GenTree(int depth)
{

	if (depth < m_depth) {

		m_childCount = 8;
		for (int i = 0; i < 8; i++) {
			m_pChildren[i] = new MyOctant(m_depth, CreateSubdivision(i), m_pEntityMngr, m_pMeshMngr);
			m_pChildren[i]->m_pParent = this;

			m_pChildren[i]->MoveEntities();
			if (m_pChildren[i]->m_vEntityList.size() > MINIMUM_ENTITIES) {
				m_pChildren[i]->GenTree(depth + 1);
			}
		}
	}
	else {
		m_childCount = 0;
		m_pParent = nullptr;
	}
}

void Simplex::MyOctant::CheckCollision(int depth)
{

	if (depth < m_depth) {


		if (m_vEntityList.size() > 0) {
			for (int i = 0; i < m_vEntityList.size() - 1; i++) {
				for (int j = i + 1; j < m_vEntityList.size(); j++) {
					m_vEntityList[i]->IsColliding(m_vEntityList[j]);
				}
			}
		}


		for (int k = 0; k < m_childCount; k++) {
			m_pChildren[k]->CheckCollision(depth + 1);
		}
	}
}

AABB * Simplex::MyOctant::CreateSubdivision(int index)
{

	vector3 min;
	vector3 max;
	vector3 half = m_pAABB->maximum - m_pAABB->minimum;
	half.x = half.x / 2;
	half.y = half.y / 2;
	half.z = half.z / 2;

	switch (index)
	{

	case 0:
		min = m_pAABB->minimum;
		max = vector3(m_pAABB->minimum.x + half.x,
			m_pAABB->minimum.y + half.y,
			m_pAABB->minimum.z + half.z);
		break;



	case 1:
		min = vector3(m_pAABB->minimum.x + half.x,
			m_pAABB->minimum.y,
			m_pAABB->minimum.z);
		max = vector3(m_pAABB->maximum.x,
			m_pAABB->minimum.y + half.y,
			m_pAABB->minimum.z + half.z);
		break;


	case 2:
		min = vector3(m_pAABB->minimum.x,
			m_pAABB->minimum.y + half.y,
			m_pAABB->minimum.z);
		max = vector3(m_pAABB->minimum.x + half.x,
			m_pAABB->maximum.y,
			m_pAABB->minimum.z + half.z);
		break;


	case 3:
		min = vector3(m_pAABB->minimum.x + half.x,
			m_pAABB->minimum.y + half.y,
			m_pAABB->minimum.z);
		max = vector3(m_pAABB->maximum.x,
			m_pAABB->maximum.y,
			m_pAABB->minimum.z + half.z);
		break;


	case 4:
		min = vector3(m_pAABB->minimum.x,
			m_pAABB->minimum.y,
			m_pAABB->minimum.z + half.z);
		max = vector3(m_pAABB->minimum.x + half.x,
			m_pAABB->minimum.y + half.y,
			m_pAABB->maximum.z);
		break;

	case 5:
		min = vector3(m_pAABB->minimum.x + half.x,
			m_pAABB->minimum.y,
			m_pAABB->minimum.z + half.z);
		max = vector3(m_pAABB->maximum.x,
			m_pAABB->minimum.y + half.y,
			m_pAABB->maximum.z);
		break;


	case 6:
		min = vector3(m_pAABB->minimum.x,
			m_pAABB->minimum.y + half.y,
			m_pAABB->minimum.z + half.z);
		max = vector3(m_pAABB->minimum.x + half.x,
			m_pAABB->maximum.y,
			m_pAABB->maximum.z);
		break;

	case 7:
		min = vector3(m_pAABB->minimum.x + half.x,
			m_pAABB->minimum.y + half.y,
			m_pAABB->minimum.z + half.z);
		max = m_pAABB->maximum;
		break;

	default:
		min = vector3(0, 0, 0);
		max = vector3(0, 0, 0);
		break;
	}

	return new AABB(min, max);
}

void Simplex::MyOctant::MoveEntities()
{

	AABB aabb = AABB();
	for (int i = 0; i < m_pParent->m_vEntityList.size(); i++) {

		aabb = AABB(m_pParent->m_vEntityList[i]->GetRigidBody()->GetMinGlobal(),
			m_pParent->m_vEntityList[i]->GetRigidBody()->GetMaxGlobal());

		if (m_pAABB->Contains(&aabb)) {
			m_vEntityList.push_back(m_pParent->m_vEntityList[i]);
			m_pParent->m_vEntityList.erase(m_pParent->m_vEntityList.begin() + i);
			i--;
		}
	}
}

Simplex::MyOctant::MyOctant(int depth, AABB * aabb, MyEntityManager * entityManager, MeshManager * meshManager)
{
	m_depth = depth;
	m_pEntityMngr = entityManager;
	m_pMeshMngr = meshManager;
	m_pAABB = aabb;
}

Simplex::MyOctant::~MyOctant()
{

	for (int i = 0; i < m_childCount; i++) {
		SafeDelete(m_pChildren[i]);
	}


	for (int j = 0; j < m_vEntityList.size(); j++) {
		SafeDelete(m_vEntityList[j]);
	}
}

void Simplex::MyOctant::Display()
{
	int depth = 1;

	if (depth < m_depth) {
		Display(depth);
	}
}

void Simplex::MyOctant::GenTree()
{
	int depth = 1;
	m_vEntityList = std::vector<MyEntity*>();
	for (int i = 0; i < m_pEntityMngr->GetEntityCount(); i++) {
		m_vEntityList.push_back(m_pEntityMngr->GetEntity(i));
	}

	if (depth < m_depth) {
		GenTree(depth);
	}
}

void Simplex::MyOctant::CheckCollision()
{
	int depth = 1;
	if (depth < m_depth) {
		CheckCollision(depth);
	}
}

Simplex::AABB::~AABB()
{
}
